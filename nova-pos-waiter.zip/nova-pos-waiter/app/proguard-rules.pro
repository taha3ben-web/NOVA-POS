# FILE: app/proguard-rules.pro
-keep class com.google.zxing.** { *; }
-keep class com.journeyapps.barcodescanner.** { *; }
