// FILE: app/src/main/java/com/my/nova/MainActivity.java
package com.my.nova;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "nova_pos_prefs";
    private static final String KEY_SERVER_URL = "server_url";
    private static final int REQ_SCAN = 1001;

    private EditText etServerUrl;
    private Button btnScanQR;
    private Button btnConnect;
    private ImageButton btnShowQR;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        etServerUrl = findViewById(R.id.etServerUrl);
        btnScanQR = findViewById(R.id.btnScanQR);
        btnConnect = findViewById(R.id.btnConnect);
        btnShowQR = findViewById(R.id.btnShowQR);

        // Load saved URL
        String savedUrl = prefs.getString(KEY_SERVER_URL, "http://192.168.1.100:3000");
        etServerUrl.setText(savedUrl);

        btnScanQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ScannerActivity.class);
                startActivityForResult(intent, REQ_SCAN);
            }
        });

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = etServerUrl.getText().toString().trim();
                if (TextUtils.isEmpty(url)) {
                    Toast.makeText(MainActivity.this, "الرجاء إدخال رابط الخادم", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "http://" + url;
                }
                prefs.edit().putString(KEY_SERVER_URL, url).apply();

                Intent intent = new Intent(MainActivity.this, WaiterActivity.class);
                intent.putExtra("server_url", url);
                startActivity(intent);
            }
        });

        btnShowQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = etServerUrl.getText().toString().trim();
                if (TextUtils.isEmpty(url)) {
                    Toast.makeText(MainActivity.this, "أدخل رابطًا أولاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                showQrDialog(url);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCAN && resultCode == RESULT_OK && data != null) {
            String scanned = data.getStringExtra("scan_result");
            if (!TextUtils.isEmpty(scanned)) {
                etServerUrl.setText(scanned);
                Toast.makeText(this, "تم المسح بنجاح", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showQrDialog(String content) {
        try {
            int size = 600;
            BitMatrix matrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, size, size);
            Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
            for (int x = 0; x < size; x++) {
                for (int y = 0; y < size; y++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                }
            }

            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_qr, null);
            ImageView ivQr = dialogView.findViewById(R.id.ivQr);
            ivQr.setImageBitmap(bitmap);

            new AlertDialog.Builder(this)
                    .setTitle("QR للرابط الحالي")
                    .setView(dialogView)
                    .setPositiveButton("إغلاق", null)
                    .show();
        } catch (WriterException e) {
            Toast.makeText(this, "فشل توليد QR", Toast.LENGTH_SHORT).show();
        }
    }
}
