NOTE: gradle-wrapper.jar needs to be downloaded
Download from: https://github.com/gradle/gradle/raw/v7.6.1/gradle/wrapper/gradle-wrapper.jar
